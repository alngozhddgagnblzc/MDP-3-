package com.example.test

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnSaveHaveIngre: Button = findViewById(R.id.btnSaveHaveIngre)
        val btnGoToRecipe: Button = findViewById(R.id.btnGoToRecipe)

        btnSaveHaveIngre.setOnClickListener {
            sendSignal()
        }

        btnGoToRecipe.setOnClickListener {
            val intent = Intent(this, RecipeActivity::class.java)
            startActivity(intent)
        }
    }

    private fun sendSignal() {
        val request = Request.Builder()
            .url("http://192.168.137.75:5000/save_have_ingre")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "신호 입력 실패", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "신호 입력", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }
}

