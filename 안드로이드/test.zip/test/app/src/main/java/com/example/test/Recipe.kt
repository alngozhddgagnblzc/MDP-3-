package com.example.test

data class Recipe(
    val recipe_id: String,
    val recipe_name: String,
    val ingre_1: String?,
    val ingre_2: String?,
    val ingre_3: String?,
    val ingre_4: String?,
    val ingre_5: String?
)

data class RecipesResponse(
    val recipes: List<Recipe>
)

data class NameMapping(
    val id: String,
    val name: String
)
