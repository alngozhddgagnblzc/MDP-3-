package com.example.test

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RecipeActivity : AppCompatActivity() {
    private lateinit var recipeContainer: LinearLayout

    // ID와 한글 이름의 매핑
    private val nameMappings = mapOf(
        "101" to "김치찌개",
        "102" to "김치볶음밥",
        "103" to "볶음밥",
        "104" to "돼지볶음마늘",
        "201" to "돼지고기",
        "202" to "대파",
        "203" to "양배추",
        "204" to "고추",
        "205" to "양파",
        "206" to "무",
        "207" to "김치",
        "208" to "마늘"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipe)

        recipeContainer = findViewById(R.id.recipeContainer)
        val btnFetchRecipes: Button = findViewById(R.id.btnFetchRecipes)

        btnFetchRecipes.setOnClickListener {
            fetchRecipes()
        }
    }

    private fun fetchRecipes() {
        RetrofitClient.instance.getRecipes().enqueue(object : Callback<RecipesResponse> {
            override fun onResponse(call: Call<RecipesResponse>, response: Response<RecipesResponse>) {
                if (response.isSuccessful) {
                    response.body()?.recipes?.let { recipes ->
                        recipeContainer.removeAllViews()
                        recipes.forEach { recipe ->
                            val ingredients = listOfNotNull(
                                nameMappings[recipe.ingre_1],
                                nameMappings[recipe.ingre_2],
                                nameMappings[recipe.ingre_3],
                                nameMappings[recipe.ingre_4],
                                nameMappings[recipe.ingre_5]
                            ).joinToString(", ")

                            val recipeButton = Button(this@RecipeActivity).apply {
                                text = "${nameMappings[recipe.recipe_id] ?: recipe.recipe_id}\nIngredients: $ingredients"
                                setOnClickListener {
                                    Toast.makeText(this@RecipeActivity, "Selected: ${nameMappings[recipe.recipe_id] ?: recipe.recipe_id}", Toast.LENGTH_SHORT).show()
                                }
                            }
                            recipeContainer.addView(recipeButton)
                        }
                    }
                } else {
                    Toast.makeText(this@RecipeActivity, "Error: ${response.errorBody()?.string()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<RecipesResponse>, t: Throwable) {
                Toast.makeText(this@RecipeActivity, "Failed to get recipes: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}

