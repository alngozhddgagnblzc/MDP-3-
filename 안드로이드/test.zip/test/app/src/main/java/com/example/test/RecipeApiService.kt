package com.example.test

import retrofit2.Call
import retrofit2.http.GET

interface RecipeApiService {
    @GET("recipe")
    fun getRecipes(): Call<RecipesResponse>
}

